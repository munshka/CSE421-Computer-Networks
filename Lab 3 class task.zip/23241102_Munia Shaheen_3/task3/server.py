# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 21:22:45 2023

@author: Munia Shaheen
"""

import socket 
import threading

HEADER = 64 
FORMAT = 'utf-8' 
SERVER = socket.gethostbyname(socket.gethostname()) #server ip
PORT   = 5050   #random registered port address
DISCONNECT_MSG = 'End' 
ADDR= (SERVER, PORT) #(ip,port)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) #socket object (address-family, TCP)

server.bind(ADDR) #bind bcz server socket address do not change

print("SERVER IS STARTING... . . . . . . ") 

#Listening Stage 
server.listen() 
print("SERVER IS LISTENING ON", SERVER) 

#Accepting Stage 
def handle_clients(conn,addr):
    #conn, addr = server.accept()  #client Socket object, client socket address
    print("CONNECTED TO", addr) 
    connected = True 
    while connected: 
        msg_length = conn.recv(HEADER).decode(FORMAT) 
        if msg_length: 
            msg_length= int(msg_length) 
            msg = conn.recv(msg_length).decode(FORMAT) 
            
            if msg == DISCONNECT_MSG: 
                connected= False 
                conn.send(f'TERMINATING THE CONNECTION WITH {addr}'.encode(FORMAT))
            else:
                vowels = "aeiouAEIOU" 
                count = 0 
                for elem in msg: 
                    if elem in vowels: 
                        count+=1 
                
                if count == 0: 
                    conn.send("Not enough vowels".encode(FORMAT)) 
                elif count<=2: 
                    conn.send("Enough vowels I guess".encode(FORMAT)) 
                else:
                    conn.send("Too many vowels".encode(FORMAT))
                
                
    conn.close()
    
    
while True: 
    conn, addr = server.accept() 
    thread = threading.Thread(target=handle_clients, args=(conn, addr)) 
    thread.start()
    
    
    
    
    
    
    
    
    
    
    
    
    
    